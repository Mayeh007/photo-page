PHOTO QR WEBSITE — GITHUB PAGES

This folder contains:
- index.html: the page that shows only the picture
- photo.jpeg: your uploaded picture

PUBLISH IT FREE WITH GITHUB PAGES
1. Sign in at https://github.com/
2. Click the + button (top right) and choose New repository.
3. Name it: photo-page
4. Set it to Public, then click Create repository.
5. On the repository page, choose Add file > Upload files.
6. Upload BOTH index.html and photo.jpeg from this folder.
7. Click Commit changes.
8. Open Settings > Pages.
9. Under Build and deployment, choose Deploy from a branch.
10. Select branch main and folder /(root), then click Save.
11. Wait a minute or two and refresh the Pages screen. GitHub will show your live website URL.

Your URL will usually look like:
https://YOUR-GITHUB-USERNAME.github.io/photo-page/

QR CODE
Once the website URL works on your phone, create a QR code that links to that exact URL using a QR-code generator. Scan-test it before sharing. The QR code should point to the published website URL, not to a file on your computer.

Note: Anyone with the link or QR code can view the photo. Do not upload anything you want to keep private.
